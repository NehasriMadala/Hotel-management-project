from tkinter import*
from PIL import Image,ImageTk
from guests import Guests
from room import roomb
from detailss import details

class Mainpage:
    def __init__(self,root):
        self.root=root
        self.root.title("5 Star Hotel")
        self.root.geometry("1550x800+0+0")

        img4=Image.open(r"c:\hotel5.png")
        img4=img4.resize((400,400),Image.LANCZOS)
        self.photoimage4=ImageTk.PhotoImage(img4)
        lblimg4=Label(image=self.photoimage4,bg="black",borderwidth=0,)
        lblimg4.place(x=0,y=0,width=400,height=300)
        

        img3=Image.open(r"c:\hotelimgg.png")
        img3=img3.resize((1100,400),Image.LANCZOS)
        self.photoimage3=ImageTk.PhotoImage(img3)
        lblimg3=Label(image=self.photoimage3,bg="black",borderwidth=0,)
        lblimg3.place(x=400,y=0,width=1100,height=300)
        

        #title
        lbl_title=Label(self.root,text="***5 Star Hotel***",font=("times new roman",40,"bold"),bg="white",fg="red")
        lbl_title.place(x=0,y=300,width=1550,height=50)

        #frame
        mainframe=Frame(self.root,bd=4,relief=RIDGE)
        mainframe.place(x=0,y=350,width=1550,height=620)

        lbl_title=Label(self.root,text="MENU",font=("times new roman",20,"bold"),bg="black",fg="gold")
        lbl_title.place(x=0,y=350,width=200,height=20)

#creating inner frame for entering buttons and all
        menu_frame=Frame(self.root,bg="white")
        menu_frame.place(x=0,y=370,width=200,height=190)

#keeping buttons in inner frame
        btn_cus= Button(menu_frame,text="Customer",command=self.guests_details,width=18,font=("the new roman",14,"bold"),bg="red",fg="white",bd=0,cursor="hand1")
        btn_cus.grid(row=0,column=0,pady=1)

        btn_room= Button(menu_frame,text="Rooms",command=self.room_det,width=18,font=("the new roman",14,"bold"),bg="red",fg="white",bd=0,cursor="hand1")
        btn_room.grid(row=1,column=0,pady=1)


        btn_det= Button(menu_frame,text="Details",command=self.det_room,width=18,font=("the new roman",14,"bold"),bg="red",fg="white",bd=0,cursor="hand1")
        btn_det.grid(row=2,column=0,pady=1)

        btn_rep= Button(menu_frame,text="Report",width=18,font=("the new roman",14,"bold"),bg="red",fg="white",bd=0,cursor="hand1")
        btn_rep.grid(row=3,column=0,pady=1)


        btn_out= Button(menu_frame,text="Logout",width=18,font=("the new roman",14,"bold"),bg="red",fg="white",bd=0,cursor="hand1")
        btn_out.grid(row=4,column=0)


        #aadding more images
        imag5=Image.open(r"c:\hotel3.png")
        imag5=imag5.resize((200,240),Image.LANCZOS)
        self.photoimage5=ImageTk.PhotoImage(imag5)
        lblimag5=Label(image=self.photoimage5,bg="black",borderwidth=0,)
        lblimag5.place(x=0,y=560,width=200,height=240)



        img6=Image.open(r"c:\hotel6.png")
        img6=img6.resize((400,440),Image.LANCZOS)
        self.photoimage6=ImageTk.PhotoImage(img6)
        lblimg6=Label(image=self.photoimage6,bg="black",borderwidth=0,)
        lblimg6.place(x=200,y=350,width=400,height=440)


        img7=Image.open(r"c:\hotel7.png")
        img7=img7.resize((950,440),Image.LANCZOS)
        self.photoimage7=ImageTk.PhotoImage(img7)
        lblimg7=Label(image=self.photoimage7,bg="black",borderwidth=0,)
        lblimg7.place(x=600,y=350,width=950,height=440)

        #for customer/guests
    def guests_details(self):
        self.gwin=Toplevel(self.root)
        self.app=Guests(self.gwin)

        # for room page



    def room_det(self):
        self.gwin=Toplevel(self.root)
        self.app=roomb(self.gwin)


    
#details

    
    def det_room(self):
        self.gwin=Toplevel(self.root)
        self.app=details(self.gwin)


if __name__=="__main__":
    root=Tk()
    obj=Mainpage(root)
    root.mainloop()