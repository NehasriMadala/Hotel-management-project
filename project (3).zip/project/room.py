from tkinter import*
from PIL import Image,ImageTk
import random
from tkinter import ttk
import mysql.connector
from tkinter import messagebox
from time import strftime
from datetime import datetime


class roomb:  
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel")
        self.root.geometry("1200x500+200+400")


        #variables
        self.con_var=StringVar()
        self.checkin_var=StringVar()
        self.checkout_var=StringVar()
        self.roomtype_var=StringVar()
        self.roomavail_var=StringVar()
        self.meal_var=StringVar()
        self.noofdays_var=StringVar()
        self.amtpaid_var=StringVar()
        self.total_var=StringVar()
        

    



        lbl_title=Label(self.root,text="Room booking",font=("times new roman",20,"bold"),bg="black",fg="gold")
        lbl_title.place(x=0,y=0,width=1550,height=50)

        img4=Image.open(r"c:\hotel5.png")
        img4=img4.resize((40,40),Image.LANCZOS)
        self.photoimage4=ImageTk.PhotoImage(img4)
        lblimg4=Label(image=self.photoimage4,bg="black",borderwidth=0,)
        lblimg4.place(x=5,y=2,width=40,height=40)


        labelf=LabelFrame(self.root,bd=2,relief=RIDGE,text="Room Booking Details",font=("times new roman",14,"bold"),padx=2,)
        labelf.place(x=5,y=50,width=425,height=550)

        #labels entries and fields
        lbl_guestrcon=Label(labelf,text="Customer contact",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestrcon.grid(row=0,column=0,sticky=W)
        
        guestrcon=ttk.Entry(labelf,textvariable=self.con_var,font=("times new roman",12,"bold"),width=22)
        guestrcon.grid(row=0,column=1,sticky=W)

#fetch data button
        Btnfetchdata=Button(labelf,command=self.fetch_contact,text="Fetch data",font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnfetchdata.place(x=310,y=4)
     

        btn_frame=Frame(labelf,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=400,width=400,height=80)

        Btnbill=Button(btn_frame,text="Bill",command=self.total,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnbill.grid(row=0,column=0,padx=1)

        # add button 
        Btnadd=Button(btn_frame,text="Add",command=self.add_data,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnadd.grid(row=1,column=0,padx=1)

        Btnup=Button(btn_frame,text="Update",command=self.update,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnup.grid(row=1,column=1,padx=1)

        Btndel=Button(btn_frame,text="Delete",command=self.delete,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btndel.grid(row=1,column=2,padx=1)

        Btnre=Button(btn_frame,text="Reset",command=self.reset,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnre.grid(row=1,column=3,padx=1)



        lbl_guestrin=Label(labelf,text="Check in date",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestrin.grid(row=1,column=0)

        guestrin=ttk.Entry(labelf,width=22,textvariable=self.checkin_var,font=("times new roman",12,"bold"))
        guestrin.grid(row=1,column=1)

        lbl_guestrout=Label(labelf,text="Check out date",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestrout.grid(row=2,column=0)

        guestrout=ttk.Entry(labelf,width=22,textvariable=self.checkout_var,font=("times new roman",12,"bold"))
        guestrout.grid(row=2,column=1)

        lbl_guestrtype=Label(labelf,text="Room type",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestrtype.grid(row=3,column=0)


        combo_guestr=ttk.Combobox(labelf,textvariable=self.roomtype_var,font=("arial",12,"bold"),width=27,state="readonly")
        combo_guestr["value"]=("Single","Double","Family","Other")
        combo_guestr.current(0)
        combo_guestr.grid(row=3,column=1)


        lbl_guestav=Label(labelf,text="Available room",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestav.grid(row=5,column=0)

        guestav=ttk.Entry(labelf,width=22,textvariable=self.roomavail_var,font=("times new roman",12,"bold"))
        guestav.grid(row=5,column=1)


        lbl_guestmeal=Label(labelf,text="Meal",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestmeal.grid(row=6,column=0)

        guestmeal=ttk.Entry(labelf,textvariable=self.meal_var,width=22,font=("times new roman",12,"bold"))
        guestmeal.grid(row=6,column=1)

        lbl_guestdays=Label(labelf,text="No of days",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestdays.grid(row=7,column=0)

        guestdays=ttk.Entry(labelf,textvariable=self.noofdays_var,width=22,font=("times new roman",12,"bold"))
        guestdays.grid(row=7,column=1)

        lbl_guestpaid=Label(labelf,text="Tax paid",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestpaid.grid(row=8,column=0)

        guestpaid=ttk.Entry(labelf,textvariable=self.amtpaid_var,width=22,font=("times new roman",12,"bold"))
        guestpaid.grid(row=8,column=1)

        lbl_guestt=Label(labelf,text="Total",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestt.grid(row=9,column=0)

        guestt=ttk.Entry(labelf,width=22,textvariable=self.total_var,font=("times new roman",12,"bold"))
        guestt.grid(row=9,column=1)



        img13=Image.open(r"c:\hotelimg.png")
        img13=img13.resize((1100,400),Image.LANCZOS)
        self.photoimage13=ImageTk.PhotoImage(img13)
        lblimg13=Label(image=self.photoimage13,bg="black",borderwidth=0,)
        lblimg13.place(x=800,y=50,width=600,height=300)

        



        #search and the other the right frame

        labelr=LabelFrame(self.root,bd=2,relief=RIDGE,text="View details and Search",font=("times new roman",14,"bold"),padx=2,)
        labelr.place(x=450,y=350,width=1000,height=400)

        lbl_guest_search=Label(labelr,text="search by",font=("times new roman",12,"bold"),bg="black",fg="gold")
        lbl_guest_search.grid(row=0,column=0,padx=3)

        self.search_var=StringVar()
        combo_search=ttk.Combobox(labelr,font=("arial",12,"bold"),width=20,state="readonly")
        combo_search["value"]=("Contact","room")
        combo_search.current(0)
        combo_search.grid(row=0,column=1,padx=3)

        self.txt_search=StringVar()
        searchentry=ttk.Entry(labelr,width=22,font=("times new roman",12,"bold"))
        searchentry.grid(row=0,column=2,padx=2)

        Btnse=Button(labelr,text="Search",command=self.search,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnse.grid(row=0,column=3,padx=1)

        Btnshow=Button(labelr,text="ShowAll",command=self.fetch_data,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnshow.grid(row=0,column=4,padx=1)

        dettable=Frame(labelr,bd=2,relief=RIDGE)
        dettable.place(x=0,y=50,width=900,height=300)


# to show data in table
        dettable=Frame(labelr,bd=2,relief=RIDGE)
        dettable.place(x=0,y=50,width=900,height=300)

        scroll_x=ttk.Scrollbar(dettable,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(dettable,orient=VERTICAL)

        self.roomtable=ttk.Treeview(dettable,column=("contacts","checkindate","checkoutdate","roomtype","roomavailable","meal","noofdays"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.roomtable.xview)
        scroll_y.config(command=self.roomtable.yview)

        
        self.roomtable.heading("contacts",text="contact")
        self.roomtable.heading("checkindate",text="checkindate")
        self.roomtable.heading("checkoutdate",text="checkoutdate")
        self.roomtable.heading("roomtype",text="roomtype")
        self.roomtable.heading("roomavailable",text="roomavailable")
        self.roomtable.heading("meal",text="meal")
        self.roomtable.heading("noofdays",text="noofdays")
        

        #show
        self.roomtable["show"]="headings"

        self.roomtable.column("contacts",width=100)
        self.roomtable.column("checkindate",width=100)
        self.roomtable.column("checkoutdate",width=100)
        self.roomtable.column("roomtype",width=100)
        self.roomtable.column("roomavailable",width=100)
        self.roomtable.column("meal",width=100)
        self.roomtable.column("noofdays",width=100)
        

        self.roomtable.pack(fill=BOTH,expand=1)
        self.roomtable.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()

    
    def add_data(self):
        if self.con_var.get() == "" or self.checkin_var.get() == "":
            messagebox.showerror("Error", "All fields required", parent=self.root)
        else:
            try:

            # Establishing the connection to MySQL database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project"
                )
                my_cursor = conn.cursor()

            # Prepare the data to be inserted into the database
                my_cursor.execute(
                "INSERT INTO rooms (contacts, checkin, checkout, roomtype, roomavailable, meal, noofdays) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (
                    self.con_var.get(),
                    self.checkin_var.get(),
                    self.checkout_var.get(),
                    self.roomtype_var.get(),
                    self.roomavail_var.get(),
                    self.meal_var.get(),
                    self.noofdays_var.get()
                    
                )
                )

            # Commit the transaction and close the connection
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Room booked", parent=self.root)

            except mysql.connector.Error as err:
            
            
                messagebox.showerror("Error", f"Error: {err}", parent=self.root)

                    
        

                conn.commit()
                self.fetch_data
                conn.close()

                messagebox.showinfo("Success","Added new Customer")

            except Exception as es:
                messagebox.showwarning("Warning",f"Oops!Something went wrong:{str(es)}",parent=self.root)

        #fetching data from data base to display 

    def fetch_data(self):

            conn=mysql.connector.connect(host="localhost",username="root",password="Nehasri@576",database="project")
            my_cursor=conn.cursor()
            my_cursor.execute("select * from rooms")
            rows=my_cursor.fetchall()
            if len(rows)!=0:
                self.roomtable.delete(*self.roomtable.get_children())
                for i in rows:
                    self.roomtable.insert("",END,values=i)
                conn.commit()
            conn.close()

            #get cursor
    def get_cursor(self, event=""):
        cursor_row=self.roomtable.focus() 
        content=self.roomtable.item(cursor_row)
        row=content["values"]


        self.con_var.set(row[0])
        self.checkin_var.set(row[1])
        self.checkout_var.set(row[2])
        self.roomtype_var.set(row[3])
        self.roomavail_var.set(row[4])
        self.meal_var.set(row[5])
        self.noofdays_var.set(row[6])

        
    #working on update btn2
    def update(self):
        if self.con_var.get() == "":
            messagebox.showerror("Error", "Enter a mobile number", parent=self.root)
        else:


        
            try:
            # Connect to the database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project"
                )
                my_cursor = conn.cursor()

            # Update query with WHERE clause
                my_cursor.execute("""
                UPDATE rooms 
                SET             
                    contacts = %s, 
                    checkin = %s, 
                    checkout = %s, 
                    roomtype = %s,  
                    meal = %s, 
                    noofdays = %s
                WHERE
                    roomavailable=%s                   
                    
                """, (
                    self.con_var.get(),
                    self.checkin_var.get(),
                    self.checkout_var.get(),
                    self.roomtype_var.get(),
                    self.meal_var.get(),
                    self.noofdays_var.get(),
                    self.roomavail_var.get(),
                    ))

            # Commit the changes and confirm update
                conn.commit()
                messagebox.showinfo("Success", "Room record updated successfully", parent=self.root)

            # Refresh data
                self.fetch_data()

            except mysql.connector.Error as err:
            # Handle database-related errors
                 messagebox.showerror("Database Error", f"Error: {err}", parent=self.root)

            finally:

            # Ensure the connection is closed
                if 'conn' in locals() and conn.is_connected():
                    conn.close()


    #del button
    def delete(self):
    
    # Confirm deletion
        delete = messagebox.askyesno("Confirmation", "Are you sure you want to delete this customer?", parent=self.root)

        if delete:

            try:

            # Connect to the database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project",
                )
                my_cursor = conn.cursor()

            # Execute delete query
                query = "DELETE FROM rooms WHERE contacts = %s"
                value = (self.con_var.get(),)
                my_cursor.execute(query, value)

            # Commit changes
                conn.commit()
                messagebox.showinfo("Success", "Customer record deleted successfully", parent=self.root)

            # Refresh data
                self.fetch_data()
            except mysql.connector.Error as err:

            # Handle database-related errors
                messagebox.showerror("Database Error", f"Error: {err}", parent=self.root)
            finally:

            # Ensure the connection is closed
                if 'conn' in locals() and conn.is_connected():

                    conn.close()
                
                else:
        # If deletion is canceled, just return
                    return
                


    #reset
    def reset(self):
        self.con_var.set("")
        self.checkin_var.set("")
        self.checkout_var.set("")
        self.roomavail_var.set("")
        self.meal_var.set("")
        self.noofdays_var.set("")
        self.amtpaid_var.set("")
        self.total_var.set("")


    def fetch_contact(self):
        if self.con_var.get()=="":
            messagebox.showerror("Error","enter contact number",parent=self.root)
        else:
            conn=mysql.connector.connect(host="localhost",username="root",password="Nehasri@576",database="project")
            my_cursor=conn.cursor()
            query=("select Name from customer where Mobile=%s")
            value=(self.con_var.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()

            if row==None:
                messagebox.showerror("Error","user not found",parent=self.root)
            else:
                conn.commit()
                

                showDataframe=Frame(self.root,bd=4,relief=RIDGE,padx=3)
                showDataframe.place(x=455,y=55,width=300,height=180)
        

        #name
                lblName=Label(showDataframe,text="Name:",font=("arial",12,"bold"))
                lblName.place(x=0,y=0)
                #this will fetch the data from database
                lbl=Label(showDataframe,text=row,font=("arial",12,"bold"))
                lbl.place(x=90,y=0)

                #
                my_cursor=conn.cursor()
                query=("select Gender from customer where Mobile=%s")
                value=(self.con_var.get(),)
                my_cursor.execute(query,value)
                row=my_cursor.fetchone()

                lblGender=Label(showDataframe,text="Gender:",font=("arial",12,"bold"))
                lblGender.place(x=0,y=30)
                #this will fetch the data from database
                lbl2=Label(showDataframe,text=row,font=("arial",12,"bold"))
                lbl2.place(x=90,y=30)

                my_cursor=conn.cursor()
                query=("select Email from customer where Mobile=%s")
                value=(self.con_var.get(),)
                my_cursor.execute(query,value)
                row=my_cursor.fetchone()

                lblemail=Label(showDataframe,text="email:",font=("arial",12,"bold"))
                lblemail.place(x=0,y=60)
                #this will fetch the data from database
                lbl3=Label(showDataframe,text=row,font=("arial",12,"bold"))
                lbl3.place(x=90,y=60)
                

                my_cursor=conn.cursor()
                query=("select Nationality from customer where Mobile=%s")
                value=(self.con_var.get(),)
                my_cursor.execute(query,value)
                row=my_cursor.fetchone()    

                lblnation=Label(showDataframe,text="Nationality:",font=("arial",12,"bold"))
                lblnation.place(x=0,y=90)
                #this will fetch the data from database
                lbl4=Label(showDataframe,text=row,font=("arial",12,"bold"))
                lbl4.place(x=90,y=90)



#search system
    def search(self):
    

    # Establish connection
        conn = mysql.connector.connect(
        host="localhost",
        username="root",
        password="Nehasri@576",
        database="project",
        )
        my_cursor = conn.cursor()

    # Whitelist of allowed columns
        allowed_columns = ["contacts", "checkin", "checkout", "roomtype", "roomavailable", "meal", "noofdays"]

        try:
        # Validate search column
            search_column = self.search_var.get()
            print(f"Search Column: {search_column}")  # Debugging statement
            if search_column not in allowed_columns:
                print("Error: Invalid column name")
                return

        # Validate search text
            search_text = self.txt_search.get().strip()
            if not search_text:
                print("Error: Search text cannot be empty")
                return

        # Perform the search query
            query = f"SELECT * FROM rooms WHERE {search_column} LIKE %s"
            search_value = f"%{search_text}%"
            print(f"Executing query: {query} with value {search_value}")  # Debugging statement
            my_cursor.execute(query, (search_value,))

        # Fetch and display the results
            rows = my_cursor.fetchall()
            if rows:
                self.roomtable.delete(*self.roomtable.get_children())  # Clear the table
                for i in rows:
                    self.roomtable.insert("", END, values=i)  # Insert each row
            else:
                print("No records found")
        except mysql.connector.Error as e:
            print(f"Database Error: {e}")
        finally:
            conn.close()  # Ensure the connection is closed














    def total(self):
        try:
        # Get dates from variables
            inDate = self.checkin_var.get()
            outDate = self.checkout_var.get()

        # Parse dates
            inDate = datetime.strptime(inDate, "%d/%m/%Y")
            outDate = datetime.strptime(outDate, "%d/%m/%Y")

        # Calculate total number of days
            total_days = (outDate - inDate).days

        # Ensure the number of days is non-negative
            if total_days < 0:
                messagebox.showerror("Error", "Check-out date must be after check-in date", parent=self.root)
                return  # Exit function if dates are invalid
            else:
                self.noofdays_var.set(total_days)

        # Meal and room type logic
            meal = self.meal_var.get().lower()
            room = self.roomtype_var.get().lower()
            no_of_days = float(self.noofdays_var.get())

            rent = 0  # Base rent
            tax_rate = 0  # Tax percentage

        # Conditions for room type and meal type
            if meal == "breakfast" and room == "single":

                rent = 1000  # Room rent + meal cost
                tax_rate = 0.05  # 5% tax
            elif meal == "breakfast" and room == "double":
                rent = 3000
                tax_rate = 0.015  # 1.5% tax
            elif meal == "lunch" and room == "single":
                rent = 2300
                tax_rate = 0.01  # 1% tax
            elif meal in ["lunch", "dinner"] and room == "double":
                rent = 3200
                tax_rate = 0.02  # 2% tax
            elif meal in ["lunch", "dinner"] and room == "family":
            
                rent = 4500
                tax_rate = 0.02  # 2% tax
            elif meal == "breakfast" and room == "family":
                rent = 4200
                tax_rate = 0.02  # 2% tax
            else:
                messagebox.showerror("Error", "Invalid meal or room type selected", parent=self.root)
                return

        # Cost Calculation
            subtotal = no_of_days * rent
            tax = subtotal * tax_rate
            total_cost = subtotal + tax

        # Set calculated values
            self.amtpaid_var.set(f"Rs. {tax:.2f}")
            self.total_var.set(f"Rs. {total_cost:.2f}")

        except ValueError:
        # Handle invalid date formats
            messagebox.showerror("Error", "Invalid date format. Please enter in DD/MM/YYYY format", parent=self.root)


















if __name__=="__main__":
    root=Tk()
    obj=roomb(root)
    root.mainloop()
