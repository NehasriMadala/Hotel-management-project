from tkinter import *
from PIL import Image, ImageTk
import random
from tkinter import ttk
import mysql.connector
from tkinter import messagebox
from time import strftime
from datetime import datetime

class details:  
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Room Booking System")
        self.root.geometry("1200x500+200+400")

        lbl_title = Label(self.root, text="ROOM BOOKING DETAILS", font=("times new roman", 20, "bold"), bg="black", fg="gold")
        lbl_title.place(x=0, y=0, width=1550, height=50)

        # Left Frame
        labelf = LabelFrame(self.root, bd=2, relief=RIDGE, text="Add new rooms", font=("times new roman", 14, "bold"), padx=2)
        labelf.place(x=5, y=50, width=540, height=350)


        #text variables
        self.floor_var=StringVar()
        self.roomno_var=StringVar()
        self.roomtype_var=StringVar()
        

        # Labels and Entries
        lbl_floor = Label(labelf, text="Floor No", font=("times new roman", 12, "bold"), padx=2, pady=6)
        lbl_floor.grid(row=0, column=0, sticky=W)
        
        self.floor = ttk.Entry(labelf,textvariable=self.floor_var, font=("times new roman", 12, "bold"), width=22)
        self.floor.grid(row=0, column=1, sticky=W)

        lbl_roomno = Label(labelf, text="Room No", font=("times new roman", 12, "bold"), padx=2, pady=6)
        lbl_roomno.grid(row=1, column=0, sticky=W)
        
        self.roomno = ttk.Entry(labelf,textvariable=self.roomno_var, font=("times new roman", 12, "bold"), width=22)
        self.roomno.grid(row=1, column=1, sticky=W)

        lbl_rtype = Label(labelf, text="Room Type", font=("times new roman", 12, "bold"), padx=2, pady=6)
        lbl_rtype.grid(row=2, column=0, sticky=W)
        
        self.rtype = ttk.Entry(labelf,textvariable=self.roomtype_var, font=("times new roman", 12, "bold"), width=22)
        self.rtype.grid(row=2, column=1, sticky=W)






        # Button frame and buttons
        btn_frame = Frame(labelf, bd=2, relief=RIDGE)
        btn_frame.place(x=0, y=200, width=400, height=80)

        # Add button
        Btnadd = Button(btn_frame, text="Add",command=self.add_data, font=("arial", 12, "bold"), bg="red", fg="white", width=9)
        Btnadd.grid(row=1, column=0, padx=1)

        Btnup = Button(btn_frame, text="Update", font=("arial", 12, "bold"), bg="red", fg="white", width=9)
        Btnup.grid(row=1, column=1, padx=1)

        Btndel = Button(btn_frame, text="Delete", font=("arial", 12, "bold"), bg="red", fg="white", width=9)
        Btndel.grid(row=1, column=2, padx=1)

        Btnre = Button(btn_frame, text="Reset",command=self.reset_fields, font=("arial", 12, "bold"), bg="red", fg="white", width=9)
        Btnre.grid(row=1, column=3, padx=1)

        # Right Frame
        labelr = LabelFrame(self.root, bd=2, relief=RIDGE, text="Show room details", font=("times new roman", 14, "bold"), padx=2)
        labelr.place(x=600, y=50, width=600, height=350)

        scroll_x = ttk.Scrollbar(labelr, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(labelr, orient=VERTICAL)

        self.room_det = ttk.Treeview(labelr, column=("floor", "roomno", "roomtype"),
                                     xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)
        
        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.room_det.xview)
        scroll_y.config(command=self.room_det.yview)

        self.room_det.heading("floor", text="Floor")
        self.room_det.heading("roomno", text="Room No")
        self.room_det.heading("roomtype", text="Room Type")
        

        self.room_det["show"] = "headings"

        self.room_det.column("floor", width=100)
        self.room_det.column("roomno", width=100)
        self.room_det.column("roomtype", width=100)
        

        self.room_det.pack(fill=BOTH, expand=1)      
        self.fetch_data()



    def add_data(self):
        if self.roomno_var.get() == "" or self.roomtype_var.get() == "":
            messagebox.showerror("Error", "All fields required", parent=self.root)
        else:
            try:

            # Establishing the connection to MySQL database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project"
                )
                my_cursor = conn.cursor()

            # Prepare the data to be inserted into the database
                my_cursor.execute(
                "INSERT INTO details (floor,roomno,roomtype) "
                "VALUES (%s, %s, %s)",
                (
                    
                    self.floor_var.get(),
                    self.roomno_var.get(),
                    self.roomtype_var.get()
                    
                )
                )

            # Commit the transaction and close the connection
                conn.commit()
                self.fetch_data
                conn.close()
                messagebox.showinfo("Success", "Room added", parent=self.root)

            except mysql.connector.Error as err:
            
            
                messagebox.showerror("Error", f"Error: {err}", parent=self.root)

                    
        

                conn.commit()
                self.fetch_data
                conn.close()

                messagebox.showinfo("Success","Added new Customer")

            except Exception as es:
                messagebox.showwarning("Warning",f"Oops!Something went wrong:{str(es)}",parent=self.root)




    def fetch_data(self):

            conn=mysql.connector.connect(host="localhost",username="root",password="Nehasri@576",database="project")
            my_cursor=conn.cursor()
            my_cursor.execute("select * from details")
            rows=my_cursor.fetchall()
            if len(rows)!=0:
                self.room_det.delete(*self.room_det.get_children())
                for i in rows:
                    self.room_det.insert("",END,values=i)
                conn.commit()
            conn.close()

    

    def reset_fields(self):
        self.floor.delete(0, END)
        self.roomno.delete(0, END)
        self.rtype.delete(0, END)


    #update and get cursor
    def get_cursor(self, event=""):
        cursor_row=self.room_det.focus() 
        content=self.room_det.item(cursor_row)
        row=content["values"]


        self.floor_var.set(row[0])
        self.roomno_var.set(row[1])
        self.roomtype_var.set(row[2])
        

        
    #working on update btn2
    def update(self):
        if self.floor_var.get() == "":
            messagebox.showerror("Error", "Enter a room number", parent=self.root)
        else:


        
            try:
            # Connect to the database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project"
                )
                my_cursor = conn.cursor()

            # Update query with WHERE clause
                my_cursor.execute("""
                UPDATE details 
                SET             
                    floor = %s, 
                    roomtype = %s, 
                    
                WHERE
                    roomno=%s                   
                    
                """, (
                    self.floor_var.get(),
                    self.roomno_var.get(),
                    self.roomtype_var.get(),
                    
                    ))

            # Commit the changes and confirm update
                conn.commit()
                messagebox.showinfo("Success", "Room record updated successfully", parent=self.root)

            # Refresh data
                self.fetch_data()

            except mysql.connector.Error as err:
            # Handle database-related errors
                 messagebox.showerror("Database Error", f"Error: {err}", parent=self.root)

            finally:

            # Ensure the connection is closed
                if 'conn' in locals() and conn.is_connected():
                    conn.close()






if __name__ == "__main__":
    root = Tk()
    obj = details(root)
    root.mainloop()
