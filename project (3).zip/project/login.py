
import bcrypt
from tkinter import*
from tkinter import ttk
from PIL import Image, ImageTk  
from tkinter import messagebox
from Mainpg import Mainpage
import mysql.connector



class Login_in:   
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1550x1800+0+0")
    
        self.bg=ImageTk.PhotoImage(file=r"c:\Users\madal\OneDrive\Desktop\hotel2.png")
        lbl_bg=Label(self.root,image=self.bg)
        lbl_bg.place(x=0,y=0,relwidth=1,relheight=1)
        frame=Frame(self.root,bg="black")
        frame.place(x=610,y=170,width=350,height=450)

        img1=Image.open(r"c:\Users\madal\OneDrive\Desktop\logo1.png")
        img1=img1.resize((100,100),Image.LANCZOS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        lblimg1=Label(image=self.photoimage1,bg="black",borderwidth=0,)
        lblimg1.place(x=730,y=175,width=100,height=100)

        get_str=Label(frame,text="Get Started",font=("times new roman",20,"bold"),fg="white",bg="black")
        get_str.place(x=95,y=100)

#label1
        username=lbl=Label(frame,text="Username",font=("times new roman",15,"bold"),fg="white",bg="black")
        username.place(x=70,y=155)

        self.txtuser=ttk.Entry(frame,font=("times new roman",15,"bold"))
        self.txtuser.place(x=40,y=185,width=270)
#label2
        password=lbl=Label(frame,text="password",font=("times new roman",15,"bold"),fg="white",bg="black")
        password.place(x=70,y=215)

        self.txtpass=ttk.Entry(frame,font=("times new roman",15,"bold"),show="*")
        self.txtpass.place(x=40,y=245,width=270)

#login button
        logbn=Button(frame,text="Login",command=self.login,font=("times new roman",15,"bold"),bd=3,relief=RIDGE,fg="white",bg="red",activeforeground="white",activebackground="red")
        logbn.place(x=110,y=300,width=120,height=35)
         

        regbn=Button(frame,text="New user?Register",font=("times new roman",10,"bold"),borderwidth=0,fg="white",bg="black",activeforeground="white",activebackground="red")
        regbn.place(x=20,y=350,width=160)

        fpassbn=Button(frame,text="forgot password",font=("times new roman",10,"bold"),borderwidth=0,fg="white",bg="black",activeforeground="white",activebackground="red")
        fpassbn.place(x=140,y=390,width=160)

    def login(self):
        if self.txtuser.get()==""or self.txtpass.get()=="":
                messagebox.showerror("Error","Enter all the details")
        elif self.txtuser.get()=="neha" and self.txtpass.get()=="Nehasri@576":
             messagebox.showinfo("Success","Welcome") 
        else:
           messagebox.showerror("Invalid","Invalid username and password") 

           conn=mysql.connector.connect(host="localhost",username="root",password="Nehasri@576",database="project")
           my_cursor=conn.cursor()
           my_cursor.execute("select* from register where email=%s and password=%s",(self.txtuser.get(),self.txtpass.get()))

        #connecting to main page(i.e customer page) above


        self.name_var=StringVar()
        self.pass_var=StringVar()

        row=my_cursor.fetchone()
        if row==None:
             messagebox.showerror("Error","Invalid Username& password")
        else:
             open_main=messagebox.askyesno("YesNO","only Admin")
             if open_main>0:
                  self.wintoconn=Toplevel(self.root)
                  self.app=Mainpage(self.wintoconn)
             else:
                  if not open_main:
                       return
        
        conn.commit()
        conn.close()
        
        
    def main():
         win=Tk()
         app=Login_in(win)
         win.mainloop()






  

if __name__=="__main__":
    root=Tk()
    app=Login_in(root)
    root.mainloop()
