from tkinter import*
from PIL import Image,ImageTk
import random
from tkinter import ttk
import mysql.connector
from tkinter import messagebox

class Guests:  
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel")
        self.root.geometry("1200x500+200+400")

        # variables
        #for auto ref
        self.ref_var=StringVar()
        x=random.randint(300,1000)
        self.ref_var.set(str(x))

        self.name_var=StringVar()
        self.gen_var=StringVar()
        self.mob_var=StringVar()
        self.email_var=StringVar()
        self.nationality_var=StringVar()
        self.idproof_var=StringVar()
        self.idno_var=StringVar()



        lbl_title=Label(self.root,text="Add Customer Details",font=("times new roman",20,"bold"),bg="black",fg="gold")
        lbl_title.place(x=0,y=0,width=1550,height=50)

        img4=Image.open(r"c:\hotel5.png")
        img4=img4.resize((40,40),Image.LANCZOS)
        self.photoimage4=ImageTk.PhotoImage(img4)
        lblimg4=Label(image=self.photoimage4,bg="black",borderwidth=0,)
        lblimg4.place(x=5,y=2,width=40,height=40)


        #labelframe
        labelf=LabelFrame(self.root,bd=2,relief=RIDGE,text="Customer Details",font=("times new roman",14,"bold"),padx=2,)
        labelf.place(x=5,y=50,width=425,height=400)

        #labels entries and fields
        lbl_guestref=Label(labelf,text="Customer ref",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestref.grid(row=0,column=0,sticky=W)
        
        guestref=ttk.Entry(labelf,textvariable=self.ref_var,font=("times new roman",12,"bold"),width=22,state="readonly")
        guestref.grid(row=0,column=1)


        lbl_guestname=Label(labelf,text="Customer name",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestname.grid(row=1,column=0)

        guestname=ttk.Entry(labelf,textvariable=self.name_var,width=22,font=("times new roman",12,"bold"))
        guestname.grid(row=1,column=1)

        lbl_guestgen=Label(labelf,text="gender",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestgen.grid(row=3,column=0)


        combo_gen=ttk.Combobox(labelf,textvariable=self.gen_var,font=("arial",12,"bold"),width=27,state="readonly")
        combo_gen["value"]=("Female","Male","Other")
        combo_gen.current(0)
        combo_gen.grid(row=3,column=1)


        guestno=ttk.Entry(labelf,width=22,font=("times new roman",12,"bold"))
        guestno.grid(row=2,column=1)



        lbl_guestno=Label(labelf,text="Mobile no",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestno.grid(row=2,column=0)

        guestno=ttk.Entry(labelf,textvariable=self.mob_var,width=22,font=("times new roman",12,"bold"))
        guestno.grid(row=2,column=1)
#email
        lbl_guestem=Label(labelf,text="email",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestem.grid(row=4,column=0)

        guestem=ttk.Entry(labelf,textvariable=self.email_var,width=22,font=("times new roman",12,"bold"))
        guestem.grid(row=4,column=1)

        #Nationality-combobox/checkbox
        lbl_guestnat=Label(labelf,text="Nationality",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestnat.grid(row=5,column=0)


        combo_nat=ttk.Combobox(labelf,textvariable=self.nationality_var,font=("arial",12,"bold"),width=27,state="readonly")
        combo_nat["value"]=("Indian","African","Canadian","Other")
        combo_nat.current(0)
        combo_nat.grid(row=5,column=1)


    # id proof combobox/checkbox
        lbl_guestid=Label(labelf,text="Id proof",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestid.grid(row=7,column=0)


        combo_id=ttk.Combobox(labelf,textvariable=self.idproof_var,font=("arial",12,"bold"),width=27,state="readonly")
        combo_id["value"]=("Aadhar","Passport","Other")
        combo_id.current(0)
        combo_id.grid(row=7,column=1)

        #id num
        lbl_guestidno=Label(labelf,text="Id no",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_guestidno.grid(row=8,column=0)

        guestidno=ttk.Entry(labelf,textvariable=self.idno_var,width=22,font=("times new roman",12,"bold"))
        guestidno.grid(row=8,column=1)

        #button frame
        btn_frame=Frame(labelf,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=300,width=400,height=40)

        # add button 
        Btnadd=Button(btn_frame,text="Add",command=self.add_data,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnadd.grid(row=0,column=0,padx=1)

        Btnup=Button(btn_frame,text="Update",command=self.update,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnup.grid(row=0,column=1,padx=1)

        Btndel=Button(btn_frame,text="Delete",command=self.delete,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btndel.grid(row=0,column=2,padx=1)

        Btnre=Button(btn_frame,text="Reset",command=self.reset,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnre.grid(row=0,column=3,padx=1)

        #label right
        labelr=LabelFrame(self.root,bd=2,relief=RIDGE,text="View details and Search",font=("times new roman",14,"bold"),padx=2,)
        labelr.place(x=450,y=50,width=1000,height=400)

        lbl_guest_search=Label(labelr,text="search by",font=("times new roman",12,"bold"),bg="black",fg="gold")
        lbl_guest_search.grid(row=0,column=0,padx=3)

        self.search_var=StringVar()
        combo_search=ttk.Combobox(labelr,textvariable=self.search_var,font=("arial",12,"bold"),width=20,state="readonly")
        combo_search["value"]=("Mobile","ref")
        combo_search.current(0)
        combo_search.grid(row=0,column=1,padx=3)

        self.txt_search=StringVar()
        searchentry=ttk.Entry(labelr,width=22,textvariable=self.txt_search,font=("times new roman",12,"bold"))
        searchentry.grid(row=0,column=2,padx=2)

        Btnse=Button(labelr,text="Search",command=self.search,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnse.grid(row=0,column=3,padx=1)

        Btnshow=Button(labelr,text="ShowAll",command=self.fetch_data,font=("arial",12,"bold"),bg="red",fg="white",width=9)
        Btnshow.grid(row=0,column=4,padx=1)

        dettable=Frame(labelr,bd=2,relief=RIDGE)
        dettable.place(x=0,y=50,width=900,height=300)

        scroll_x=ttk.Scrollbar(dettable,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(dettable,orient=VERTICAL)

        self.guestsdettable=ttk.Treeview(dettable,column=("ref","name","gender","Mobile","email","Nationality","Id no","Id proof"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.guestsdettable.xview)
        scroll_y.config(command=self.guestsdettable.yview)

        
        self.guestsdettable.heading("ref",text="Refer no")
        self.guestsdettable.heading("name",text="Name")
        self.guestsdettable.heading("gender",text="Gender")
        self.guestsdettable.heading("Mobile",text="Mobile")
        self.guestsdettable.heading("email",text="Email")
        self.guestsdettable.heading("Nationality",text="Nationality")
        self.guestsdettable.heading("Id proof",text="Id proof")
        self.guestsdettable.heading("Id no",text="Id no")

        #show
        self.guestsdettable["show"]="headings"

        self.guestsdettable.column("ref",width=100)
        self.guestsdettable.column("name",width=100)
        self.guestsdettable.column("gender",width=100)
        self.guestsdettable.column("Mobile",width=100)
        self.guestsdettable.column("email",width=100)
        self.guestsdettable.column("Nationality",width=100)
        self.guestsdettable.column("Id proof",width=100)
        self.guestsdettable.column("Id no",width=100)

        self.guestsdettable.pack(fill=BOTH,expand=1)
        self.guestsdettable.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()                       



#connector to database
    def add_data(self):
        if self.mob_var.get()=="":
            messagebox.showerror("Error","All fields required",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="Nehasri@576",database="project")
                my_cursor=conn.cursor()
                my_cursor.execute("insert into customer values(%s,%s,%s,%s,%s,%s,%s,%s)",(self.ref_var.get(),self.name_var.get(),self.gen_var.get(),self.mob_var.get(),self.email_var.get(),self.nationality_var.get(),self.idproof_var.get(),self.idno_var.get()))
                conn.commit()
                self.fetch_data
                conn.close()

                messagebox.showinfo("Success","Added new Customer")

            except Exception as es:
                messagebox.showwarning("Warning",f"Oops!Something went wrong:{str(es)}",parent=self.root)


    def fetch_data(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="Nehasri@576",database="project")
        my_cursor=conn.cursor()
        my_cursor.execute("select * from customer")
        rows=my_cursor.fetchall()
        if len(rows)!=0:
            self.guestsdettable.delete(*self.guestsdettable.get_children())
            for i in rows:
                self.guestsdettable.insert("",END,values=i)
                conn.commit()
            conn.close()


    def get_cursor(self, event=""):
        cursor_row=self.guestsdettable.focus() 
        content=self.guestsdettable.item(cursor_row)
        row=content["values"]


        self.ref_var.set(row[0])
        self.name_var.set(row[1])
        self.gen_var.set(row[2])
        self.mob_var.set(row[3])
        self.email_var.set(row[4])
        self.nationality_var.set(row[5])
        self.idproof_var.set(row[6])
        self.idno_var.set(row[7])

        
    #working on update btn2
    def update(self):
        if self.mob_var.get() == "":
            messagebox.showerror("Error", "Enter a mobile number", parent=self.root)
        else:


        
            try:
            # Connect to the database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project"
                )
                my_cursor = conn.cursor()

            # Update query with WHERE clause
                my_cursor.execute("""
                UPDATE customer 
                SET             
                    Name = %s, 
                    Gender = %s, 
                    Mobile = %s, 
                    Email = %s, 
                    Nationality = %s, 
                    `Id proof` = %s, 
                    `Id no` = %s
                WHERE
                    `Ref no`=%s                   
                    
                """, (
                    self.name_var.get(),
                    self.gen_var.get(),
                    self.mob_var.get(),
                    self.email_var.get(),
                    self.nationality_var.get(),
                    self.idproof_var.get(),
                    self.idno_var.get(),
                    self.ref_var.get()
                    ))

            # Commit the changes and confirm update
                conn.commit()
                messagebox.showinfo("Success", "Customer record updated successfully", parent=self.root)

            # Refresh data
                self.fetch_data()

            except mysql.connector.Error as err:
            # Handle database-related errors
                 messagebox.showerror("Database Error", f"Error: {err}", parent=self.root)

            finally:

            # Ensure the connection is closed
                if 'conn' in locals() and conn.is_connected():
                    conn.close()
    
    


    #delete
    def delete(self):
    
    # Confirm deletion
        delete = messagebox.askyesno("Confirmation", "Are you sure you want to delete this customer?", parent=self.root)

        if delete:

            try:

            # Connect to the database
                conn = mysql.connector.connect(
                host="localhost",
                username="root",
                password="Nehasri@576",
                database="project",
                )
                my_cursor = conn.cursor()

            # Execute delete query
                query = "DELETE FROM customer WHERE `Ref no` = %s"
                value = (self.ref_var.get(),)
                my_cursor.execute(query, value)

            # Commit changes
                conn.commit()
                messagebox.showinfo("Success", "Customer record deleted successfully", parent=self.root)

            # Refresh data
                self.fetch_data()
            except mysql.connector.Error as err:

            # Handle database-related errors
                messagebox.showerror("Database Error", f"Error: {err}", parent=self.root)
            finally:

            # Ensure the connection is closed
                if 'conn' in locals() and conn.is_connected():

                    conn.close()
                
                else:
        # If deletion is canceled, just return
                    return

    #reset 

    def reset(self):
        self.name_var.set("")
        self.mob_var.set("")
        self.email_var.set("")
        self.idno_var.set("")



    def search(self):
    # Establish connection
        conn = mysql.connector.connect(
        host="localhost",
        username="root",
        password="Nehasri@576",
        database="project",
        )
        my_cursor = conn.cursor()

        try:

        
            query = "SELECT * FROM customer WHERE {} LIKE %s".format(self.search_var.get())
            search_value = f"%{self.txt_search.get()}%"
            my_cursor.execute(query, (search_value,))


            rows = my_cursor.fetchall()
            if rows:

                self.guestsdettable.delete(*self.guestsdettable.get_children())  
                for i in rows:

                    self.guestsdettable.insert("", END, values=i)  
            else:
                print("No records found") 
        except mysql.connector.Error as e:
            print(f"Error: {e}")
        finally:
            conn.close()  




    



   
            








    







if __name__=="__main__":
    root=Tk()
    obj=Guests(root)
    root.mainloop()


    